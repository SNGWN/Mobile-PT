//
// Created by b3nac on 6/28/20.
//

#ifndef INJUREDANDROID_ENCRYPT_H
#define INJUREDANDROID_ENCRYPT_H

#endif //INJUREDANDROID_ENCRYPT_H
#include <string>

using namespace std;

extern "C" const char* encryptDecrypt(string encryptThis);
