package main

import "fmt"

func main() {

const test = "HIIMASTRING"

fmt.Println(test)

}
